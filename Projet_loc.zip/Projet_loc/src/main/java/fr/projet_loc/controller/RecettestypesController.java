package fr.projet_loc.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import fr.projet_loc.dao.RecettesRepository;

@Controller
@RequestMapping(value="/Recettestypes",method = RequestMethod.GET) 
public class RecettestypesController {
	
	@Autowired
	private RecettesRepository repository;
	
	@RequestMapping("/index")
	public ModelAndView index(@RequestParam("id") int id) {
		final ModelAndView mav = new ModelAndView("MenuDuJour/list");
		mav.getModel().put("menuDuJourList",this.repository.findByTypes(id));
		return mav;
	}

}
