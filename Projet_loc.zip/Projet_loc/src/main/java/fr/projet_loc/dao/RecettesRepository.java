package fr.projet_loc.dao;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import fr.projet_loc.entity.Recettes;

public interface RecettesRepository extends JpaRepository<Recettes, Integer> {

	 Iterable<Recettes> findById(int i, Sort sort);
	 List <Recettes> findByTypes(int types);
	 List <Recettes> findByVeg(boolean veg);
	
}





