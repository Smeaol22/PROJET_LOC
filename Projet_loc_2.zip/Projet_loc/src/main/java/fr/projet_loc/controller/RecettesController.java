package fr.projet_loc.controller;

import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import fr.projet_loc.dao.IngredientsRepository;
import fr.projet_loc.dao.RecettesIngredientsRepository;
import fr.projet_loc.dao.RecettesRepository;
import fr.projet_loc.entity.Recettes;

@Controller
@RequestMapping(value="/Recettes", method = RequestMethod.GET)
public class RecettesController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RecettesController.class);

	@Autowired
	private RecettesRepository recettesRepository;
	
	@Autowired
	private IngredientsRepository ingredientsRepository;
	
	@Autowired
	private RecettesIngredientsRepository recettesIngredientsRepository;
	
	@RequestMapping("/index")
	public ModelAndView index(@RequestParam(value="recettejour", required=false) Boolean recettejour,@RequestParam(value="id", required=false) Integer id, @RequestParam(value="veg", required=false) Boolean veg) {
		if (recettejour != null){
			final ModelAndView mav = new ModelAndView("MenuDuJour/list");
			mav.getModel().put("menuDuJourList",this.recettesRepository.findById(ThreadLocalRandom.current().nextInt(1, 3 + 1), null));
			mav.getModel().put("ingredientsDuJourList", this.recettesIngredientsRepository.findAllByRecettesId(1));
			return mav;
		}
		else{
			final ModelAndView mav = new ModelAndView("Recettes/list");
			if(id == null && veg != null)
			{
				mav.getModel().put("menuDuJourList",this.recettesRepository.findByVeg(veg));
				return mav;
			}
			
			else if (veg==null && id!=null){
				mav.getModel().put("menuDuJourList",this.recettesRepository.findByTypes(id));
				return mav;
			
			}
			else if(veg==null && id==null ){
				mav.getModel().put("menuDuJourList", this.recettesRepository.findAll());
				return mav;
			}
			else {
				mav.getModel().put("menuDuJourList",((RecettesRepository) this.recettesRepository.findByTypes(id)).findByVeg(veg));
				return mav;
			}
			
		}
		
	}


	

	/*@RequestMapping(path = "/edit/{id}")
	public String showUpdate(final Model model, @PathVariable final Integer id) {
		if (this.repository.exists(id)) {
			model.addAttribute("Recettes", this.repository.findOne(id));
			return "/Recettes/edit";
		} else {
			RecettesController.LOGGER
					.warn("Trying to update a Recettes with a unknown id '{}' in database. Switching to creation.", id);
			return this.showCreate(model);
		}
	}

	@RequestMapping(path = "/edit", method = RequestMethod.GET)
	public String showCreate(final Model model) {
		model.addAttribute("Recettes", new Recettes());
		return "Recettes/edit";
	}

	@RequestMapping(path = "/edit", method = RequestMethod.POST)
	public String createOrUpdate(@ModelAttribute final Recettes recettes) {
		this.repository.save(recettes);
		return "redirect:/Recettes/";
	}

	@RequestMapping("/delete")
	public String delete(@RequestParam final Integer id) {
		if (this.repository.exists(id)) {
			this.repository.delete(id);
		} else {
			RecettesController.LOGGER.warn("Cannot delete Recettes, id={} does not exists in database.", id);
		}
		return "redirect:/Recettes/";
	}*/
}
