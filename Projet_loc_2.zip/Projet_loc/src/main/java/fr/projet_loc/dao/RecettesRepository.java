package fr.projet_loc.dao;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import fr.projet_loc.entity.Recettes;

public interface RecettesRepository extends JpaRepository<Recettes, Integer> {

	 Iterable<Recettes> findById(Integer i, Sort sort);
	 List <Recettes> findByTypes(Integer types);
	 List <Recettes> findByVeg(Boolean veg);
	/* List <Recettes> findByTypesVeg(Boolean veg, Integer types);*/
	
}





